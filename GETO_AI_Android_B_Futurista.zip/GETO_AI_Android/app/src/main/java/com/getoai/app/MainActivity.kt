package com.getoai.app

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.content.ActivityNotFoundException
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.net.Uri
import android.util.Base64
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import java.util.Locale
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.*
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.*
import java.io.ByteArrayOutputStream
import java.util.concurrent.TimeUnit

private val Ink = Color(0xFF080A10)       // negro grafito
private val Panel = Color(0xFF141821)    // carbón azulado
private val Violet = Color(0xFF9C82E8)   // violeta suave
private val Muted = Color(0xFFB9BFCC)    // plata
private val White = Color(0xFFF3F4F8)

class MainActivity : ComponentActivity() {
    private val askPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) {}
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            askPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        setContent { GetoApp(this) }
    }
}
data class ChatLine(val role: String, val text: String)

@Composable
fun GetoApp(ctx: Context) {
    val prefs = remember { ctx.getSharedPreferences("geto_data", Context.MODE_PRIVATE) }
    var tab by remember { mutableIntStateOf(0) }
    var input by remember { mutableStateOf("") }
    var memoryInput by remember { mutableStateOf("") }
    var reminderInput by remember { mutableStateOf("") }
    var minutes by remember { mutableStateOf("30") }
    var busy by remember { mutableStateOf(false) }
    var chat by remember { mutableStateOf(loadChat(prefs)) }
    var memories by remember { mutableStateOf(prefs.getStringSet("memories", emptySet())!!.toList()) }
    val scope = rememberCoroutineScope()
    var imageData by remember { mutableStateOf<String?>(null) }
    var imageName by remember { mutableStateOf<String?>(null) }
    val tts = remember { TextToSpeech(ctx) { status ->
        if (status == TextToSpeech.SUCCESS) { /* initialized */ }
    } }
    DisposableEffect(tts) {
        onDispose { tts.stop(); tts.shutdown() }
    }
    val imagePicker = androidx.activity.compose.rememberLauncherForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            try {
                val bytes = ctx.contentResolver.openInputStream(uri)?.use { it.readBytes() }
                if (bytes != null && bytes.size <= 8 * 1024 * 1024) {
                    imageData = Base64.encodeToString(bytes, Base64.NO_WRAP)
                    imageName = "Imagen adjunta"
                } else {
                    imageData = null
                    imageName = "La imagen supera el límite de 8 MB"
                }
            } catch (_: Exception) {
                imageData = null
                imageName = "No se pudo leer la imagen"
            }
        }
    }
    val speechLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val spoken = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (!spoken.isNullOrBlank()) input = (input + " " + spoken).trim()
    }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Ink, surface = Panel, primary = Violet, onPrimary = Color.White,
        onBackground = White, onSurface = White, secondary = Muted
    )) {
        Scaffold(containerColor = Ink, bottomBar = {
            NavigationBar(containerColor = Panel) {
                NavigationBarItem(tab == 0, { tab = 0 }, icon = { Icon(Icons.Default.Chat, null) }, label = { Text("Chat") })
                NavigationBarItem(tab == 1, { tab = 1 }, icon = { Icon(Icons.Default.Psychology, null) }, label = { Text("Memoria") })
                NavigationBarItem(tab == 2, { tab = 2 }, icon = { Icon(Icons.Default.Notifications, null) }, label = { Text("Avisos") })
            }
        }) { pad ->
            Column(Modifier.fillMaxSize().padding(pad).padding(horizontal = 16.dp)) {
                Row(Modifier.fillMaxWidth().padding(vertical = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(42.dp).background(Violet.copy(alpha = .18f), CircleShape), contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.Flare, null, tint = Violet)
                    }
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text("G E T O   A I", color = White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        Text("INTELIGENCIA A TU SERVICIO", color = Muted, fontSize = 9.sp, letterSpacing = 1.2.sp)
                    }
                    Spacer(Modifier.weight(1f))
                    Text("●  ONLINE", color = Muted, fontSize = 9.sp, letterSpacing = 1.sp)
                }
                when (tab) {
                    0 -> {
                        Text("Buenas. ¿Qué resolveremos hoy?", color = White, fontSize = 21.sp, fontWeight = FontWeight.SemiBold)
                        Text("Piensa con calma. Yo ordenaré las ideas.", color = Muted, fontSize = 13.sp,
                            modifier = Modifier.padding(top = 5.dp, bottom = 12.dp))
                        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            items(chat) { ChatBubble(it) }
                            if (busy) item { Text("GETO está pensando…", color = Violet) }
                        }
                        if (imageName != null) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Image, null, tint = Violet)
                                Text(imageName!!, color = Muted, fontSize = 12.sp, modifier = Modifier.weight(1f))
                                TextButton(onClick = { imageData = null; imageName = null }) { Text("Quitar") }
                            }
                        }
                        Row(Modifier.fillMaxWidth().padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                            IconButton(onClick = { imagePicker.launch("image/*") }, enabled = !busy) {
                                Icon(Icons.Default.AddPhotoAlternate, "Adjuntar imagen", tint = Violet)
                            }
                            IconButton(onClick = {
                                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-EC")
                                    putExtra(RecognizerIntent.EXTRA_PROMPT, "Habla con GETO")
                                }
                                try { speechLauncher.launch(intent) } catch (_: ActivityNotFoundException) { }
                            }, enabled = !busy) { Icon(Icons.Default.Mic, "Dictar", tint = Violet) }
                            OutlinedTextField(input, { input = it }, modifier = Modifier.weight(1f),
                                placeholder = { Text("Escribe…", color = Muted) }, maxLines = 4,
                                shape = RoundedCornerShape(18.dp), colors = fieldColors())
                            IconButton(enabled = !busy, onClick = {
                                val q = input.trim()
                                if (q.isNotEmpty() || imageData != null) {
                                    input = ""
                                    val attached = imageData
                                    imageData = null; imageName = null
                                    val updated = chat + ChatLine("user", if (q.isBlank()) "Analiza esta imagen." else q)
                                    chat = updated; saveChat(prefs, chat); busy = true
                                    val remembered = maybeRemember(q, memories)
                                    if (remembered != memories) {
                                        memories = remembered
                                        prefs.edit().putStringSet("memories", memories.toSet()).apply()
                                    }
                                    scope.launch {
                                        val reply = askGeto(q.ifBlank { "Analiza la imagen adjunta y explica lo que contiene." },
                                            memories, updated.dropLast(1).takeLast(12), attached)
                                        chat = chat + ChatLine("assistant", reply); saveChat(prefs, chat)
                                        tts.language = Locale("es", "EC")
                                        tts.speak(reply, TextToSpeech.QUEUE_FLUSH, null, "geto_reply")
                                        busy = false
                                    }
                                }
                            }) { Icon(Icons.Default.Send, null, tint = Violet) }
                        }
                    }
                    1 -> {
                        Text("Memoria de GETO", color = White, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
                        Text("Guarda información útil para futuras conversaciones.", color = Muted, fontSize = 13.sp,
                            modifier = Modifier.padding(vertical = 12.dp))
                        OutlinedTextField(memoryInput, { memoryInput = it }, modifier = Modifier.fillMaxWidth(),
                            placeholder = { Text("Ej. Estoy en bachillerato y estudio física") }, colors = fieldColors())
                        Button(onClick = {
                            val v = memoryInput.trim()
                            if (v.isNotEmpty()) {
                                memories = (memories + v).distinct()
                                prefs.edit().putStringSet("memories", memories.toSet()).apply(); memoryInput = ""
                            }
                        }, modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Violet)) {
                            Icon(Icons.Default.Add, null); Spacer(Modifier.width(6.dp)); Text("Guardar en memoria")
                        }
                        Text("Recuerdos guardados", color = White, fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.padding(vertical = 18.dp))
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(memories) { item ->
                                Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(12.dp)).padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically) {
                                    Text(item, color = White, modifier = Modifier.weight(1f), fontSize = 14.sp)
                                    IconButton(onClick = {
                                        memories = memories.filterNot { it == item }
                                        prefs.edit().putStringSet("memories", memories.toSet()).apply()
                                    }) { Icon(Icons.Default.DeleteOutline, null, tint = Muted) }
                                }
                            }
                        }
                    }
                    else -> {
                        Text("Recordatorios", color = White, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
                        Text("GETO te avisará cuando llegue el momento.", color = Muted, modifier = Modifier.padding(vertical = 12.dp))
                        OutlinedTextField(reminderInput, { reminderInput = it }, modifier = Modifier.fillMaxWidth(),
                            placeholder = { Text("¿Qué no debes olvidar?") }, colors = fieldColors())
                        OutlinedTextField(minutes, { minutes = it.filter(Char::isDigit) }, modifier = Modifier.fillMaxWidth().padding(top = 10.dp),
                            label = { Text("Avisar dentro de cuántos minutos") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), colors = fieldColors())
                        Button(onClick = {
                            val title = reminderInput.trim(); val mins = minutes.toLongOrNull() ?: 0L
                            if (title.isNotEmpty() && mins > 0) { scheduleReminder(ctx, title, mins); reminderInput = "" }
                        }, modifier = Modifier.fillMaxWidth().padding(top = 10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Violet)) {
                            Icon(Icons.Default.AlarmAdd, null); Spacer(Modifier.width(6.dp)); Text("Programar recordatorio")
                        }
                    }
                }
            }
        }
    }
}
@Composable fun fieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = Violet, unfocusedBorderColor = Muted, focusedTextColor = White,
    unfocusedTextColor = White, focusedLabelColor = Violet, unfocusedLabelColor = Muted
)
@Composable fun ChatBubble(line: ChatLine) {
    val mine = line.role == "user"
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start) {
        Column(Modifier.widthIn(max = 310.dp).background(if (mine) Color(0xFF302448) else Panel, RoundedCornerShape(16.dp)).padding(12.dp)) {
            Text(if (mine) "TÚ" else "GETO", color = Violet, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(4.dp)); Text(line.text, color = White, fontSize = 14.sp)
        }
    }
}
fun loadChat(p: android.content.SharedPreferences): List<ChatLine> = try {
    val a = JSONArray(p.getString("chat", "[]"))
    (0 until a.length()).map { val o = a.getJSONObject(it); ChatLine(o.getString("role"), o.getString("text")) }
} catch (_: Exception) { listOf(ChatLine("assistant", "Soy GETO. Cuéntame qué necesitas y lo analizaremos.")) }
fun saveChat(p: android.content.SharedPreferences, lines: List<ChatLine>) {
    val a = JSONArray()
    lines.takeLast(80).forEach { a.put(JSONObject().put("role", it.role).put("text", it.text)) }
    p.edit().putString("chat", a.toString()).apply()
}

fun maybeRemember(text: String, current: List<String>): List<String> {
    val t = text.trim()
    val lower = t.lowercase(Locale.ROOT)
    val prefixes = listOf("recuerda que ", "recuerda: ", "mi nombre es ", "prefiero ", "estudio ", "mi objetivo es ")
    val prefix = prefixes.firstOrNull { lower.startsWith(it) } ?: return current
    val fact = t.removePrefix(t.substring(0, prefix.length)).trim()
    if (fact.length < 3) return current
    return (current + fact).distinct().takeLast(100)
}

suspend fun askGeto(q: String, memories: List<String>, history: List<ChatLine>, imageBase64: String? = null): String = withContext(Dispatchers.IO) {
    try {
        val arr = JSONArray()
        val mem = if (memories.isEmpty()) "Todavía no hay recuerdos guardados." else memories.joinToString("\n")
        val systemPrompt = "Eres GETO AI, asistente académico y personal sereno, elegante, inteligente y sutilmente sarcástico, inspirado en un personaje de ficción. No afirmes ser el personaje oficial. Ayudas a un estudiante: explica paso a paso y fomenta el aprendizaje. Responde en español salvo petición contraria. Sé respetuoso. Si el usuario expresa explícitamente un dato para recordar, anímale a guardarlo en la sección Memoria si no se detectó automáticamente.\nMemoria del usuario:\n$mem"
        arr.put(JSONObject().put("role", "system").put("content", systemPrompt))
        history.takeLast(10).forEach { if (it.role == "user" || it.role == "assistant") arr.put(JSONObject().put("role", it.role).put("content", it.text)) }
        val userContent: Any = if (imageBase64 == null) q else JSONArray()
            .put(JSONObject().put("type", "text").put("text", q))
            .put(JSONObject().put("type", "image_url").put("image_url",
                JSONObject().put("url", "data:image/jpeg;base64,$imageBase64")))
        arr.put(JSONObject().put("role", "user").put("content", userContent))
        val body = JSONObject().put("messages", arr).toString().toRequestBody("application/json".toMediaType())
        val req = Request.Builder().url(BuildConfig.API_BASE_URL + "chat").post(body).build()
        OkHttpClient.Builder().callTimeout(90, TimeUnit.SECONDS).build().newCall(req).execute().use { r ->
            if (!r.isSuccessful) "El servidor respondió con error (${r.code}). Revisa la configuración."
            else JSONObject(r.body?.string() ?: "{}").optString("reply", "No recibí una respuesta válida.")
        }
    } catch (e: Exception) { "No pude conectar con la IA. Comprueba Internet y el servidor. ${e.localizedMessage ?: ""}" }
}

fun scheduleReminder(ctx: Context, title: String, mins: Long) {
    val i = Intent(ctx, ReminderReceiver::class.java).putExtra("title", title)
    val id = (System.currentTimeMillis() % Int.MAX_VALUE).toInt()
    val pi = PendingIntent.getBroadcast(ctx, id, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    val alarm = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
    val at = System.currentTimeMillis() + mins * 60_000L
    if (Build.VERSION.SDK_INT >= 23) alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi) else alarm.set(AlarmManager.RTC_WAKEUP, at, pi)
}
