import express from "express";
import cors from "cors";
import dotenv from "dotenv";
dotenv.config();
const app = express();
app.use(cors());
app.use(express.json({limit:"1mb"}));
app.get("/health", (_req,res)=>res.json({ok:true,service:"GETO AI"}));
app.post("/chat", async (req,res)=>{
  try {
    if (!process.env.OPENAI_API_KEY) return res.status(503).json({error:"Falta OPENAI_API_KEY en backend/.env"});
    if (!Array.isArray(req.body?.messages)) return res.status(400).json({error:"messages debe ser una lista"});
    const upstream = await fetch("https://api.openai.com/v1/chat/completions",{
      method:"POST",
      headers:{"Authorization":`Bearer ${process.env.OPENAI_API_KEY}`,"Content-Type":"application/json"},
      body:JSON.stringify({model:process.env.OPENAI_MODEL||"gpt-4o-mini",messages:req.body.messages,temperature:0.8})
    });
    const data = await upstream.json();
    if (!upstream.ok) return res.status(upstream.status).json({error:data.error?.message||"Error del proveedor IA"});
    res.json({reply:data.choices?.[0]?.message?.content||"No llegó una respuesta."});
  } catch(e) { res.status(500).json({error:e.message||"Error interno"}); }
});
const port=Number(process.env.PORT||3000);
app.listen(port,"0.0.0.0",()=>console.log(`GETO AI backend activo en puerto ${port}`));
